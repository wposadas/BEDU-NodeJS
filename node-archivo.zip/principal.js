var sumar = require('./modulo');
sumar(8, 2);

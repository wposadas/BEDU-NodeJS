function sumar (num1, num2) {
  console.log(num1 + num2);
};

module.exports = sumar; 
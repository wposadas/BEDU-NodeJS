const path = require('path')
const ruta
const server = require(path.join('app', 'server.js')) 

const path = require('path')
const server = require(path.join(__dirname, 'app', 'server.js')) 
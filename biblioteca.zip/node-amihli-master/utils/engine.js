const createAccount = require('../handlers/create-account');
const enableAction = (action) => {
  switch (action) {
    case 1:
      createAccount();
      break;
   
    default:
      console.log('No se ha seleccionado ninguna acción');
  }
};

module.exports = enableAction;
